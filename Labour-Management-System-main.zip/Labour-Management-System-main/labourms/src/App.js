import './index.css';
import React, { useEffect, useState, useRef } from "react";
import { BrowserRouter as Router, Routes, Route, Link, Navigate, useNavigate } from "react-router-dom";
import { auth, db, storage } from './firebase'; // Import from your firebase config
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut,
} from "firebase/auth";
import { doc, setDoc, getDoc, collection, onSnapshot, query, where, updateDoc, addDoc, serverTimestamp, getDocs, orderBy, deleteDoc, writeBatch } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL, uploadBytesResumable } from "firebase/storage";

// Helper function to format time difference in milliseconds to "Xh Ym Zs"
function formatTime(milliseconds) {
  const totalSeconds = Math.floor(milliseconds / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return `${hours}h ${minutes}m ${seconds}s`;
}

/*
  Labour Management System — Auth Demo (Single-file React component)
  - Uses Tailwind CSS classes for styling (requires Tailwind setup in your project)
  - Simple client-side demo: stores users in localStorage (NOT secure — for demo only)
  - Default demo accounts are seeded on first run.

  How to use:
  1) Put this file in src/App.jsx (or import it as your root component)
  2) Make sure you have react-router-dom and Tailwind set up
  3) Run the app and visit / (Auth UI)

  Security note: This demo uses localStorage purely to simulate auth and show UI flows.
  For a production app, implement server-side authentication (bcrypt + JWT/sessions) and HTTPS.
*/

// ---------- Auth Context (to manage user state globally) ----------
const AuthContext = React.createContext(null);

function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        // User is signed in, get their profile from Firestore
        const userDocRef = doc(db, "users", firebaseUser.uid);
        const userDoc = await getDoc(userDocRef);
        if (userDoc.exists()) {
          setUser({ ...firebaseUser, ...userDoc.data() });
        } else {
          // Handle case where user exists in Auth but not in Firestore
          setUser(firebaseUser);
        }
      } else {
        // User is signed out
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const value = { user, loading, setUser };
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

const useAuth = () => React.useContext(AuthContext);

// ---------- Protected Route ----------
function RequireAuth({ children, allowedRoles }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="min-h-screen flex items-center justify-center bg-gray-100">Loading...</div>;
  if (!user) return <Navigate to="/" replace />; // Not logged in
  if (user.role === 'worker' && user.status === 'pending') return <div className="min-h-screen flex items-center justify-center bg-gray-100">Your registration is pending approval from your supervisor.</div>;
  if (allowedRoles && !allowedRoles.includes(user.role)) return <Navigate to="/" replace />;
  return children;
}

// ---------- Dashboards (placeholders for later) ----------
function WorkerDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("overview");
  const [tasks, setTasks] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [leaves, setLeaves] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [todayAttendance, setTodayAttendance] = useState({ checkIn: null, checkOut: null });
  const [currentAttendanceDocId, setCurrentAttendanceDocId] = useState(null);

  // Real-time listeners for worker data
  useEffect(() => {
    if (!user?.uid) return;

    // Listen for tasks assigned to this worker
    const tasksQuery = query(collection(db, "tasks"), where("workerId", "==", user.uid));
    const unsubscribeTasks = onSnapshot(tasksQuery, snapshot => {
      setTasks(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    // Listen for leave requests by this worker
    const leavesQuery = query(collection(db, "leaveRequests"), where("workerId", "==", user.uid));
    const unsubscribeLeaves = onSnapshot(leavesQuery, snapshot => {
      setLeaves(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    // Listen for attendance records for this worker
    const attendanceQuery = query(collection(db, "attendance"), where("workerId", "==", user.uid));
    const unsubscribeAttendance = onSnapshot(attendanceQuery, snapshot => {
      const attendanceData = snapshot.docs.map(doc => {
        const data = doc.data();
        const checkIn = data.checkIn?.toDate();
        const checkOut = data.checkOut?.toDate();
        const hours = checkIn && checkOut ? (checkOut - checkIn) / (1000 * 60 * 60) : 0; // hours
        const formattedTime = checkIn && checkOut ? formatTime(checkOut - checkIn) : '0h 0m 0s';
        return {
          date: data.date,
          checkIn: checkIn ? checkIn.toLocaleTimeString() : '',
          checkOut: checkOut ? checkOut.toLocaleTimeString() : '',
          hours: hours,
          formattedTime: formattedTime,
        };
      });
      setAttendance(attendanceData);

      // Update todayAttendance and currentAttendanceDocId
      const today = new Date().toISOString().split('T')[0];
      const todayDocs = snapshot.docs.filter(doc => doc.data().date === today).sort((a, b) => b.data().checkIn - a.data().checkIn);
      if (todayDocs.length > 0) {
        // Latest today doc (sorted by checkIn desc, first is latest)
        const latestTodayDoc = todayDocs[0];
        const data = latestTodayDoc.data();
        const checkIn = data.checkIn?.toDate();
        const checkOut = data.checkOut?.toDate();
        setTodayAttendance({
          checkIn: checkIn || null,
          checkOut: checkOut || null,
        });
        setCurrentAttendanceDocId(latestTodayDoc.id);
      } else {
        setTodayAttendance({ checkIn: null, checkOut: null });
        setCurrentAttendanceDocId(null);
      }
    });

    return () => {
      unsubscribeTasks();
      unsubscribeLeaves();
      unsubscribeAttendance();
    };
  }, [user]);

  const handleCheckIn = async () => {
    if (!user?.uid) return;
    const today = new Date().toISOString().split('T')[0];

    // If there is an existing attendance doc for today with checkOut set, create a new doc
    if (currentAttendanceDocId && todayAttendance.checkOut) {
      try {
        await addDoc(collection(db, "attendance"), {
          workerId: user.uid,
          checkIn: serverTimestamp(),
          date: today,
        });
        alert("Checked in successfully!");
      } catch (error) {
        console.error("Error checking in (new doc): ", error);
        alert(`Failed to check in: ${error.message}`);
      }
      return;
    }

    // Otherwise update or create the existing doc
    const attendanceRef = doc(db, "attendance", currentAttendanceDocId || `${user.uid}_${today}`);
    try {
      await setDoc(attendanceRef, {
        workerId: user.uid,
        checkIn: serverTimestamp(),
        date: today,
      }, { merge: true });
      alert("Checked in successfully!");
    } catch (error) {
      console.error("Error checking in: ", error);
      alert(`Failed to check in: ${error.message}`);
    }
  };

  const handleCheckOut = async () => {
    if (!user?.uid) return;
    const today = new Date().toISOString().split('T')[0];
    const attendanceRef = doc(db, "attendance", currentAttendanceDocId || `${user.uid}_${today}`);
    try {
      await updateDoc(attendanceRef, { checkOut: serverTimestamp() });
      alert("Checked out successfully! Your hours will be calculated.");
    } catch (error) {
      console.error("Error checking out: ", error);
      alert(`Failed to check out: ${error.message}`);
    }
  };

  const handleTaskStatusChange = async (taskId, newStatus) => {
    const taskRef = doc(db, "tasks", taskId);
    await updateDoc(taskRef, { status: newStatus });
    if (newStatus === 'Completed') {
      alert(`Task marked as completed. Supervisor will be notified.`);
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case "tasks":
        return <TaskView tasks={tasks} onStatusChange={handleTaskStatusChange} />;
      case "attendance":
        return <AttendanceView attendance={attendance} today={todayAttendance} onCheckIn={handleCheckIn} onCheckOut={handleCheckOut} />;
      case "leave":
        return <LeaveView leaves={leaves} user={user} />;
      case "profile":
        return <ProfileView user={user} />;
      case "notifications":
        return <NotificationsView notifications={notifications} setNotifications={setNotifications} />;
      default:
        return <OverviewView tasks={tasks} notifications={notifications} user={user} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-6">
      <Header />
      <div className="max-w-7xl mx-auto mt-8">
        <div className="flex border-b border-gray-200">
          <TabButton label="Overview" isActive={activeTab === 'overview'} onClick={() => setActiveTab('overview')} />
          <TabButton label="Tasks" isActive={activeTab === 'tasks'} onClick={() => setActiveTab('tasks')} />
          <TabButton label="Attendance" isActive={activeTab === 'attendance'} onClick={() => setActiveTab('attendance')} />
          <TabButton label="Leave" isActive={activeTab === 'leave'} onClick={() => setActiveTab('leave')} />
          <TabButton label="Profile" isActive={activeTab === 'profile'} onClick={() => setActiveTab('profile')} />
          <TabButton label="Notifications" isActive={activeTab === 'notifications'} count={notifications.filter(n => !n.read).length} onClick={() => setActiveTab('notifications')} />
        </div>
        <div className="mt-6">
          {renderContent()}
        </div>
      </div>
    </div>
  );
}

const TabButton = ({ label, isActive, onClick, count }) => (
  <button onClick={onClick} className={`py-4 px-6 text-sm font-medium transition-colors duration-200 relative ${isActive ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}>
    {label}
    {count > 0 && <span className="absolute top-2 right-2 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">{count}</span>}
  </button>
);

const OverviewView = ({ tasks, notifications, user }) => (
  <div>
    <h2 className="text-2xl font-bold text-gray-800 mb-4">Dashboard Overview</h2>
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      <Card title="Pending Tasks" value={tasks.filter(t => t.status === 'Pending').length} />
      <Card title="In Progress Tasks" value={tasks.filter(t => t.status === 'In Progress').length} />
      <Card title="Unread Notifications" value={notifications.filter(n => !n.read).length} />
      <Card title="Monthly Salary" value={`₹${user.monthlySalary || 10000}`} />
    </div>
  </div>
);

const TaskView = ({ tasks, onStatusChange }) => {
  const handleTaskStatusChange = async (taskId, newStatus) => {
    onStatusChange(taskId, newStatus);
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 mb-4">My Work Assignments</h2>
      <div className="space-y-4">
        {tasks.map(task => (
          <div key={task.id} className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-bold text-lg text-gray-800">{task.title}</h3>
                <p className="text-sm text-gray-600 mt-1">{task.description}</p>
                <div className="text-xs text-gray-500 mt-2 space-x-4">
                  <span>📍 {task.location}</span>
                  <span>👤 {task.supervisor}</span>
                  <span>🗓️ {task.deadline}</span>
                </div>
              </div>
              <span className={`px-3 py-1 text-xs font-semibold rounded-full ${task.status === 'Completed' ? 'bg-green-100 text-green-800' : task.status === 'In Progress' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'}`}>{task.status}</span>
            </div>
            {task.status !== 'Completed' && (
              <div className="mt-4 pt-4 border-t border-gray-200 space-y-2">
                <div className="flex gap-2 items-center">
                  {task.status === 'Pending' && <button onClick={() => handleTaskStatusChange(task.id, 'In Progress')} className="px-3 py-1 text-sm bg-blue-500 text-white rounded-md hover:bg-blue-600">Start Task</button>}
                  {task.status === 'In Progress' && <button onClick={() => handleTaskStatusChange(task.id, 'Completed')} className="px-3 py-1 text-sm bg-green-500 text-white rounded-md hover:bg-green-600">Mark as Completed</button>}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

const AttendanceView = ({ attendance, today, onCheckIn, onCheckOut }) => (
  <div>
    <h2 className="text-2xl font-bold text-gray-800 mb-4">Attendance</h2>
    <div className="bg-white p-6 rounded-lg shadow-md mb-6">
      <h3 className="font-bold text-lg mb-4">Today's Clock-In</h3>
      <div className="flex gap-4 items-center">
        <button onClick={onCheckIn} disabled={!!today.checkIn && !today.checkOut} className="px-6 py-3 bg-green-500 text-white rounded-lg disabled:bg-gray-300">Check-In</button>
        <button onClick={onCheckOut} disabled={!today.checkIn || !!today.checkOut} className="px-6 py-3 bg-red-500 text-white rounded-lg disabled:bg-gray-300">Check-Out</button>
        <div className="text-sm text-gray-600">
          {today.checkIn && <div>Checked In: {today.checkIn.toLocaleTimeString()}</div>}
          {today.checkOut && <div>Checked Out: {today.checkOut.toLocaleTimeString()}</div>}
        </div>
      </div>
    </div>
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h3 className="font-bold text-lg mb-4">History</h3>
      <table className="w-full text-sm text-left">
        <thead className="bg-gray-50"><tr><th className="p-2">Date</th><th className="p-2">Check In</th><th className="p-2">Check Out</th><th className="p-2">Hours</th></tr></thead>
        <tbody>{attendance.map(a => <tr key={a.date} className="border-b"><td className="p-2">{a.date}</td><td className="p-2">{a.checkIn}</td><td className="p-2">{a.checkOut}</td><td className="p-2"><div>{a.hours.toFixed(2)}</div><div className="text-xs text-gray-500">{a.formattedTime}</div></td></tr>)}</tbody>
      </table>
    </div>
  </div>
);

const LeaveView = ({ leaves, user }) => {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [reason, setReason] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!from || !to || !reason) {
      alert("Please fill out all fields.");
      return;
    }

    if (!user.supervisorId) {
      alert("You must be assigned to a supervisor to submit leave requests.");
      return;
    }

    const today = new Date().toISOString().split('T')[0];
    if (from < today || to < today) {
      alert("Cannot select past dates for leave.");
      return;
    }

    try {
      await addDoc(collection(db, "leaveRequests"), {
        workerId: user.uid,
        workerName: user.name || 'N/A',
        supervisorId: user.supervisorId,
        from,
        to,
        reason,
        status: 'Pending',
        createdAt: serverTimestamp(),
      });

      setFrom('');
      setTo('');
      setReason('');
      alert("Leave request submitted for approval.");
    } catch (error) {
      console.error("Error submitting leave request: ", error);
      alert("Failed to submit leave request: " + error.message);
    }
  };

  const today = new Date().toISOString().split('T')[0];

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Leave / Absence</h2>
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md mb-6 space-y-4">
        <h3 className="font-bold text-lg">Request New Leave</h3>
        <div className="grid grid-cols-2 gap-4">
          <div><label className="block text-sm">From</label><input type="date" value={from} onChange={e => setFrom(e.target.value)} min={today} className="w-full p-2 border rounded-md" /></div>
          <div><label className="block text-sm">To</label><input type="date" value={to} onChange={e => setTo(e.target.value)} min={today} className="w-full p-2 border rounded-md" /></div>
        </div>
        <div><label className="block text-sm">Reason</label><textarea value={reason} onChange={e => setReason(e.target.value)} className="w-full p-2 border rounded-md" rows="3" placeholder="Please provide a reason for your absence..."></textarea></div>
        <button type="submit" className="px-6 py-2 bg-indigo-600 text-white rounded-lg">Submit Request</button>
      </form>
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="font-bold text-lg mb-4">History</h3>
        <table className="w-full text-sm text-left">
          <thead className="bg-gray-50"><tr><th className="p-2">From</th><th className="p-2">To</th><th className="p-2">Reason</th><th className="p-2">Status</th></tr></thead>
          <tbody>{leaves.map(l => <tr key={l.id} className="border-b"><td className="p-2">{l.from}</td><td className="p-2">{l.to}</td><td className="p-2">{l.reason}</td><td className="p-2"><span className={`px-2 py-1 text-xs rounded-full ${l.status === 'Approved' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>{l.status}</span></td></tr>)}</tbody>
        </table>
      </div>
    </div>
  );
};

const ProfileView = ({ user }) => {
  const { setUser } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    contact: user?.contact || '',
    address: user?.address || '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSaveProfile = async () => {
    // Validation
    if (formData.contact && !/^\d{10}$/.test(formData.contact)) {
      alert("Contact must be exactly 10 digits.");
      return;
    }

    try {
      await updateDoc(doc(db, "users", user.uid), formData);
      // Re-fetch user data to update UI
      const userDocRef = doc(db, "users", user.uid);
      const userDoc = await getDoc(userDocRef);
      if (userDoc.exists()) {
        setUser({ ...user, ...userDoc.data() });
      }
      alert("Profile updated successfully!");
      setIsEditing(false);
    } catch (error) {
      console.error("Error updating profile:", error);
      alert("Failed to update profile.");
    }
  };

  const handleCancelEdit = () => {
    setFormData({
      name: user?.name || '',
      contact: user?.contact || '',
      address: user?.address || '',
    });
    setIsEditing(false);
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 mb-4">My Profile</h2>
      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="text-sm text-gray-500">Full Name</h4>
            {isEditing ? (
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                className="w-full p-2 border rounded-md"
              />
            ) : (
              <p className="font-semibold">{user?.name}</p>
            )}
          </div>
          <div><h4 className="text-sm text-gray-500">Email</h4><p className="font-semibold">{user?.email}</p></div>
          <div>
            <h4 className="text-sm text-gray-500">Contact</h4>
            {isEditing ? (
              <input
                type="text"
                name="contact"
                value={formData.contact}
                onChange={handleInputChange}
                className="w-full p-2 border rounded-md"
              />
            ) : (
              <p className="font-semibold">{user?.contact || 'N/A'}</p>
            )}
          </div>
          <div>
            <h4 className="text-sm text-gray-500">Address</h4>
            {isEditing ? (
              <textarea
                name="address"
                value={formData.address}
                onChange={handleInputChange}
                className="w-full p-2 border rounded-md"
                rows="3"
              />
            ) : (
              <p className="font-semibold">{user?.address || 'N/A'}</p>
            )}
          </div>
          <div><h4 className="text-sm text-gray-500">Designation</h4><p className="font-semibold">General Labour</p></div>
          <div><h4 className="text-sm text-gray-500">Department</h4><p className="font-semibold">Construction</p></div>
          <div><h4 className="text-sm text-gray-500">Joining Date</h4><p className="font-semibold">2023-01-15</p></div>
        </div>
        <div className="mt-6 flex gap-4">
          {isEditing ? (
            <>
              <button onClick={handleSaveProfile} className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">Save Changes</button>
              <button onClick={handleCancelEdit} className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700">Cancel</button>
            </>
          ) : (
            <button onClick={() => setIsEditing(true)} className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">Edit Profile</button>
          )}
        </div>
      </div>
    </div>
  );
};

const NotificationsView = ({ notifications, setNotifications }) => (
  <div>
    <h2 className="text-2xl font-bold text-gray-800 mb-4">Notifications</h2>
    <div className="space-y-3">
      {notifications.map(n => (
        <div key={n.id} className={`p-4 rounded-lg flex items-center gap-4 ${n.read ? 'bg-gray-100' : 'bg-blue-50 border border-blue-200'}`}>
          <div className={`w-2 h-2 rounded-full ${n.read ? 'bg-gray-400' : 'bg-blue-500'}`}></div>
          <div className="flex-1"><p className="text-sm text-gray-800">{n.text}</p><p className="text-xs text-gray-500">{n.time}</p></div>
        </div>
      ))}
    </div>
  </div>
);

function SupervisorDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("overview");
  const [workers, setWorkers] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [leaveRequests, setLeaveRequests] = useState([]);
  const [workerAttendance, setWorkerAttendance] = useState({});
  const [registrationRequests, setRegistrationRequests] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const isUpdatingRegRequestRef = useRef(false);

  // Real-time listeners for supervisor data
  useEffect(() => {
    if (!user?.uid) return;

    // Listen for all users with the 'worker' role and supervisorId matching current supervisor
    const workersQuery = query(collection(db, "users"), where("role", "==", "worker"), where("supervisorId", "==", user.uid));
    const unsubscribeWorkers = onSnapshot(workersQuery,
      snapshot => {
        console.log("SupervisorDashboard: Workers query snapshot received. Empty:", snapshot.empty, "Docs count:", snapshot.docs.length);
        if (snapshot.empty) {
          console.warn("No workers found in the database for this supervisor.");
          setWorkers([]);
        } else {
          const fetchedWorkers = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
          console.log("SupervisorDashboard fetched workers:", fetchedWorkers);
          setWorkers(fetchedWorkers);
        }
      },
      error => {
        console.error("Error listening to workers query:", error);
      }
    );

    // Listen for tasks created by this supervisor
    const tasksQuery = query(collection(db, "tasks"), where("supervisorId", "==", user.uid));
    const unsubscribeTasks = onSnapshot(tasksQuery, snapshot => {
      setTasks(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    // Listen for pending leave requests from workers under this supervisor
    const leaveQuery = query(collection(db, "leaveRequests"), where("supervisorId", "==", user.uid), where("status", "==", "Pending"));
    const unsubscribeLeaves = onSnapshot(leaveQuery, snapshot => {
      const newRequests = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

      // Add notifications for new leave requests
      const newNotifications = newRequests.map(req => ({
        id: req.id,
        text: `Leave request from ${req.workerName}`,
        read: false,
        time: req.createdAt ? req.createdAt.toDate().toLocaleString() : new Date().toLocaleString(),
      }));

      // Filter out notifications for requests that are no longer pending
      setNotifications(prevNotifications => {
        const filtered = prevNotifications.filter(n => newRequests.some(req => req.id === n.id));
        const newOnes = newNotifications.filter(n => !prevNotifications.some(pn => pn.id === n.id));
        return [...filtered, ...newOnes];
      });

      setLeaveRequests(newRequests);
    });

    // Listen for all attendance records to calculate today's hours for workers
    const attendanceQuery = query(collection(db, "attendance"));
    const unsubscribeAttendance = onSnapshot(attendanceQuery, snapshot => {
      const attendanceData = snapshot.docs.map(doc => doc.data());
      const today = new Date().toISOString().split('T')[0];
      const todayAttendance = attendanceData.filter(a => a.date === today);
      const workerHours = {};
      todayAttendance.forEach(a => {
        const checkIn = a.checkIn?.toDate();
        const checkOut = a.checkOut?.toDate();
        const hours = checkIn && checkOut ? (checkOut - checkIn) / (1000 * 60 * 60) : 0;
        if (!workerHours[a.workerId]) workerHours[a.workerId] = 0;
        workerHours[a.workerId] += hours;
      });
      setWorkerAttendance(workerHours);
    });

    // Listen for registration requests for this supervisor
    const regRequestsQuery = query(collection(db, "registrationRequests"), where("supervisorId", "==", user.uid), where("status", "in", ["pending", "rejected"]));
    const unsubscribeRegRequests = onSnapshot(regRequestsQuery, snapshot => {
      const newRequests = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

      if (!isUpdatingRegRequestRef.current) {
        setRegistrationRequests(newRequests);
      }

      // Add notifications for new registration requests
      const newNotifications = newRequests.map(req => ({
        id: req.id,
        text: `New registration request from ${req.workerName}`,
        read: false,
        time: req.createdAt ? req.createdAt.toDate().toLocaleString() : new Date().toLocaleString(),
      }));

      // Filter out notifications for requests that are no longer pending
      setNotifications(prevNotifications => {
        const filtered = prevNotifications.filter(n => newRequests.some(req => req.id === n.id));
        const newOnes = newNotifications.filter(n => !prevNotifications.some(pn => pn.id === n.id));
        return [...filtered, ...newOnes];
      });
    });

    return () => {
      unsubscribeWorkers();
      unsubscribeTasks();
      unsubscribeLeaves();
      unsubscribeAttendance();
      unsubscribeRegRequests();
    };
  }, [user]);

  const handleLeaveRequest = async (leaveId, newStatus) => {
    const leaveRef = doc(db, "leaveRequests", leaveId);
    await updateDoc(leaveRef, { status: newStatus });

    // Remove notification for this leave request
    setNotifications(prev => prev.filter(n => n.id !== leaveId));

    alert(`Leave request has been ${newStatus.toLowerCase()}.`);
  };

  const handleRegistrationRequest = async (requestId, workerId, newStatus) => {
    const requestRef = doc(db, "registrationRequests", requestId);

    if (newStatus === 'approved') {
      try {
        // Check if a user with the same email already exists
        const regReqDoc = await getDoc(requestRef);
        if (!regReqDoc.exists()) {
          alert("Registration request not found.");
          return;
        }
        const regData = regReqDoc.data();

        const usersQuery = query(collection(db, "users"), where("email", "==", regData.workerEmail));
        const usersSnapshot = await getDocs(usersQuery);
        if (!usersSnapshot.empty) {
          alert("A user with this email already exists. Cannot assign to multiple supervisors.");
          return;
        }

        // Create user in Firebase Auth with email and password from registrationRequest
        const userCredential = await createUserWithEmailAndPassword(auth, regData.workerEmail, regData.password);
        const firebaseUser = userCredential.user;

        // Create user document in Firestore with supervisorId and status active
        await setDoc(doc(db, "users", firebaseUser.uid), {
          name: regData.workerName,
          email: regData.workerEmail,
          role: "worker",
          supervisorId: regData.supervisorId,
          status: "active",
          monthlySalary: 10000,
        });

      // Update the registration request status to 'approved'
      isUpdatingRegRequestRef.current = true;
      await updateDoc(requestRef, { status: 'approved' });

      // Manually remove from local state to ensure immediate UI update
      setRegistrationRequests(prev => prev.filter(r => r.id !== requestId));
      setNotifications(prev => prev.filter(n => n.id !== requestId));

      // Allow onSnapshot to update state after a delay to prevent override
      setTimeout(() => {
        isUpdatingRegRequestRef.current = false;
      }, 2000);

      alert("Worker registration approved.");
      } catch (error) {
        console.error("Error approving registration:", error);
        alert("Failed to approve registration: " + error.message);
      }
    } else { // 'rejected'
      try {
      // Update the registration request status to 'rejected'
      isUpdatingRegRequestRef.current = true;
      await updateDoc(requestRef, { status: 'rejected' });

      // Manually remove from local state to ensure immediate UI update
      setRegistrationRequests(prev => prev.filter(r => r.id !== requestId));
      setNotifications(prev => prev.filter(n => n.id !== requestId));

      // Allow onSnapshot to update state after a delay to prevent override
      setTimeout(() => {
        isUpdatingRegRequestRef.current = false;
      }, 2000);

      alert("Worker registration rejected. The user will need to register again.");
      } catch (error) {
        console.error("Error rejecting registration:", error);
        alert("Failed to reject registration: " + error.message);
      }
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case "workers":
        return <SupervisorWorkerView workers={workers} workerAttendance={workerAttendance} />;
      case "tasks":
        return <SupervisorTaskView tasks={tasks} workers={workers} supervisor={user} />;
      case "leave":
        return <SupervisorLeaveView leaveRequests={leaveRequests} onAction={handleLeaveRequest} />;
      case "notifications":
        return <SupervisorNotificationsView notifications={notifications} setNotifications={setNotifications} />;
      case "registrations":
        return <SupervisorRegistrationView requests={registrationRequests} onAction={handleRegistrationRequest} />;
      default:
        return <SupervisorOverviewView tasks={tasks} leaveRequests={leaveRequests} workers={workers} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 p-6">
      <Header />
      <div className="max-w-7xl mx-auto mt-8">
        <div className="flex border-b border-gray-200">
          <TabButton label="Overview" isActive={activeTab === 'overview'} onClick={() => setActiveTab('overview')} />
          <TabButton label="Workers" isActive={activeTab === 'workers'} onClick={() => setActiveTab('workers')} />
          <TabButton label="Tasks" isActive={activeTab === 'tasks'} onClick={() => setActiveTab('tasks')} />
          <TabButton label="Leave Requests" isActive={activeTab === 'leave'} count={leaveRequests.filter(lr => lr.status === 'Pending').length} onClick={() => setActiveTab('leave')} />
          <TabButton label="Notifications" isActive={activeTab === 'notifications'} count={notifications.filter(n => !n.read).length} onClick={() => setActiveTab('notifications')} />
          <TabButton label="Registration Requests" isActive={activeTab === 'registrations'} count={registrationRequests.length} onClick={() => setActiveTab('registrations')} />
        </div>
        <div className="mt-6">
          {renderContent()}
        </div>
      </div>
    </div>
  );
}

const SupervisorOverviewView = ({ tasks, leaveRequests, workers }) => (
  <div>
    <h2 className="text-2xl font-bold text-gray-800 mb-4">Supervisor Overview</h2>
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      <Card title="Workers Assigned" value={workers.length} />
      <Card title="Pending Leave Requests" value={leaveRequests.filter(lr => lr.status === 'Pending').length} />
      <Card title="Open Tasks" value={tasks.filter(t => t.status !== 'Completed').length} />
    </div>
  </div>
);

const SupervisorWorkerView = ({ workers, workerAttendance }) => {
  const setPay = async (workerId, workerName) => {
    const salary = prompt(`Set monthly salary in Rs for ${workerName}:`, "10000");
    if (salary === null) return;
    const numSalary = parseFloat(salary);
    if (isNaN(numSalary) || numSalary < 0) {
      alert("Please enter a valid monthly salary.");
      return;
    }
    try {
      await setDoc(doc(db, "users", workerId), { monthlySalary: numSalary }, { merge: true });
      alert("Monthly salary updated.");
    } catch (error) {
      console.error("Error updating monthly salary:", error);
      alert("Failed to update monthly salary.");
    }
  };

  const deleteWorker = async (workerId, workerName) => {
    if (!window.confirm(`Are you sure you want to delete ${workerName}? This action cannot be undone.`)) return;
    try {
      await deleteDoc(doc(db, "users", workerId));
      alert("Worker deleted.");
    } catch (error) {
      console.error("Error deleting worker:", error);
      alert("Failed to delete worker.");
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Worker Management</h2>
      <table className="w-full text-sm text-left">
        <thead className="bg-gray-50">
          <tr>
            <th className="p-2">Name</th>
            <th className="p-2">Monthly Salary</th>
            <th className="p-2">Working Hours</th>
            <th className="p-2">Actions</th>
          </tr>
        </thead>
        <tbody>
          {workers.map(w => {
            const hours = workerAttendance[w.id] || 0;
            const monthlySalary = w.monthlySalary || 10000;
            return (
              <tr key={w.id} className="border-b">
                <td className="p-2 font-medium">{w.name}</td>
                <td className="p-2">₹{monthlySalary}</td>
                <td className="p-2">{hours.toFixed(2)} hours</td>
                <td className="p-2">
                  <button onClick={() => setPay(w.id, w.name)} className="text-indigo-600 hover:underline mr-4">Set Pay</button>
                  <button onClick={() => deleteWorker(w.id, w.name)} className="text-red-600 hover:underline">Delete Worker</button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

const SupervisorTaskView = ({ tasks, workers, supervisor }) => {
  console.log("SupervisorTaskView: Received workers prop:", workers);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [deadline, setDeadline] = useState('');
  const [assignedWorkerId, setAssignedWorkerId] = useState('');

  const handleAssignTask = async (e) => {
    e.preventDefault();
    if (!title || !assignedWorkerId || !deadline) {
      alert("Please fill in Title, Deadline, and assign a Worker.");
      return;
    }

    // Validate assignedWorkerId exists in workers list
    const selectedWorker = workers.find(w => w.id === assignedWorkerId);
    if (!selectedWorker) {
      alert("Selected worker is invalid. Please select a valid worker.");
      return;
    }

    // Ensure supervisor name is available
    const supervisorName = supervisor.name || supervisor.email || "Supervisor";

    console.log("Assigning task. Supervisor:", supervisor);
    console.log("Supervisor role:", supervisor.role);

    try {
      await addDoc(collection(db, "tasks"), {
        title,
        description,
        location,
        deadline,
        workerId: assignedWorkerId,
        supervisorId: supervisor.uid,
        supervisor: supervisorName,
        status: 'Pending',
        createdAt: serverTimestamp(),
      });
      alert("Task assigned successfully!");
      setIsModalOpen(false);
      // Reset form
      setTitle(''); setDescription(''); setLocation(''); setDeadline(''); setAssignedWorkerId('');
    } catch (error) {
      console.error("Error assigning task: ", error);
      alert(`Failed to assign task: ${error.message}`);
    }
  };

  const handleTaskStatusChange = async (taskId, newStatus) => {
    const taskRef = doc(db, "tasks", taskId);
    await updateDoc(taskRef, { status: newStatus });
    if (newStatus === 'Completed') {
      alert(`Task marked as completed.`);
    }
  };

  const getWorkerName = (workerId) => {
    const worker = workers.find(w => w.id === workerId);
    return worker ? worker.name : 'Unknown Worker';
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Task Assignment & Tracking</h2>
      <div className="mb-6"><button onClick={() => setIsModalOpen(true)} className="px-4 py-2 bg-indigo-600 text-white rounded-lg">Assign New Task</button></div>
      <div className="space-y-4">
        {tasks.map(task => (
          <div key={task.id} className="p-4 border rounded-lg">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h3 className="font-bold">{task.title}</h3>
                <p className="text-sm text-gray-600">{task.description}</p>
                <p className="text-sm text-gray-500">Worker: {getWorkerName(task.workerId)} | Location: {task.location} | Deadline: {task.deadline}</p>
              </div>
              <span className={`px-3 py-1 text-xs font-semibold rounded-full ${task.status === 'Completed' ? 'bg-green-100 text-green-800' : task.status === 'In Progress' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'}`}>{task.status}</span>
            </div>
            {task.status === 'In Progress' && (
              <div className="mt-2">
                <button onClick={() => handleTaskStatusChange(task.id, 'Completed')} className="px-3 py-1 text-sm bg-green-500 text-white rounded-md hover:bg-green-600">Mark as Completed</button>
              </div>
            )}
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-lg">
            <h3 className="text-xl font-bold mb-4">Assign New Task</h3>
            <form onSubmit={handleAssignTask} className="space-y-4">
              <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Task Title" className="w-full p-2 border rounded" required />
              <textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Description" className="w-full p-2 border rounded"></textarea>
              <input value={location} onChange={e => setLocation(e.target.value)} placeholder="Location" className="w-full p-2 border rounded" />
              <input type="date" value={deadline} onChange={e => setDeadline(e.target.value)} min={new Date().toISOString().split('T')[0]} className="w-full p-2 border rounded" required />
              <select
                value={assignedWorkerId}
                onChange={e => setAssignedWorkerId(e.target.value)}
                className="w-full p-2 border rounded"
                required
              >
                <option value="">Select a Worker</option>
                {workers.length === 0 && <option disabled>No workers available</option>}
                {workers.map(w => (
                  <option key={w.id} value={w.id}>
                    {w.name || "(Unnamed Worker)"}
                  </option>
                ))}
              </select>
              {console.log("Workers available for assignment:", workers)}
              <div className="flex justify-end gap-4 mt-6">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded">Assign Task</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

const SupervisorRegistrationView = ({ requests, onAction }) => (
  <div className="bg-white p-6 rounded-lg shadow-md">
    <h2 className="text-2xl font-bold text-gray-800 mb-4">New Worker Registration Requests</h2>
    <div className="space-y-4">
      {requests.length === 0 && <p className="text-gray-500">No pending registration requests.</p>}
      {requests.map(req => (
        <div key={req.id} className="p-4 border rounded-lg flex justify-between items-center">
          <div>
            <h3 className="font-bold">{req.workerName}</h3>
            <p className="text-sm text-gray-600">{req.workerEmail}</p>
            <p className="text-xs text-gray-500 mt-1">
              Requested on: {req.createdAt?.toDate().toLocaleDateString()}
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => onAction(req.id, req.workerId, 'approved')}
              className="px-3 py-1 text-sm bg-green-500 text-white rounded-md"
            >
              Approve
            </button>
            <button
              onClick={() => onAction(req.id, req.workerId, 'rejected')}
              className="px-3 py-1 text-sm bg-red-500 text-white rounded-md"
            >
              Reject
            </button>
          </div>
        </div>
      ))}
    </div>
  </div>
);

const SupervisorNotificationsView = ({ notifications, setNotifications }) => {
  const markAsRead = (id) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Notifications</h2>
      {notifications.length === 0 && <p className="text-gray-500">No new notifications.</p>}
      <div className="space-y-3">
        {notifications.map(n => (
          <div key={n.id} className={`p-4 rounded-lg flex items-center gap-4 ${n.read ? 'bg-gray-100' : 'bg-blue-50 border border-blue-200'}`}>
            <div className={`w-2 h-2 rounded-full ${n.read ? 'bg-gray-400' : 'bg-blue-500'}`}></div>
            <div className="flex-1">
              <p className="text-sm text-gray-800">{n.text}</p>
              <p className="text-xs text-gray-500">{n.time}</p>
            </div>
            {!n.read && (
              <button onClick={() => markAsRead(n.id)} className="text-indigo-600 hover:underline text-xs font-semibold">Mark as read</button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

const SupervisorLeaveView = ({ leaveRequests, onAction }) => (
  <div className="bg-white p-6 rounded-lg shadow-md">
    <h2 className="text-2xl font-bold text-gray-800 mb-4">Leave Requests</h2>
    <div className="space-y-4">
      {leaveRequests.filter(lr => lr.status === 'Pending').map(lr => (
        <div key={lr.id} className="p-4 border rounded-lg flex justify-between items-center">
          <div>
            <h3 className="font-bold">{lr.workerName}</h3>
            <p className="text-sm text-gray-600">Requesting leave from {lr.from} to {lr.to}</p>
            <p className="text-xs text-gray-500 mt-1">Reason: {lr.reason}</p>
          </div>
          <div className="flex gap-2">
            <button onClick={() => onAction(lr.id, 'Approved')} className="px-3 py-1 text-sm bg-green-500 text-white rounded-md">Approve</button>
            <button onClick={() => onAction(lr.id, 'Rejected')} className="px-3 py-1 text-sm bg-red-500 text-white rounded-md">Reject</button>
          </div>
        </div>
      ))}
      {leaveRequests.filter(lr => lr.status === 'Pending').length === 0 && <p className="text-gray-500">No pending leave requests.</p>}
    </div>
  </div>
);

function AdminDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("overview");
  const [allUsers, setAllUsers] = useState([]);
  const [projects, setProjects] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [payroll, setPayroll] = useState([]);
  const [systemSettings, setSystemSettings] = useState({});
  const [registrationRequests, setRegistrationRequests] = useState([]);

  // Real-time listeners for admin data
  useEffect(() => {
    if (!user) return;

    // Users collection
    const usersUnsubscribe = onSnapshot(collection(db, "users"), (snapshot) => {
      setAllUsers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    // Projects collection
    const projectsUnsubscribe = onSnapshot(collection(db, "projects"), (snapshot) => {
      setProjects(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    // Tasks collection
    const tasksUnsubscribe = onSnapshot(collection(db, "tasks"), (snapshot) => {
      setTasks(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    // Payroll collection
    const payrollUnsubscribe = onSnapshot(collection(db, "payroll"), (snapshot) => {
      setPayroll(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    // System settings collection
    const settingsUnsubscribe = onSnapshot(collection(db, "systemSettings"), (snapshot) => {
      if (!snapshot.empty) {
        const settingsDoc = snapshot.docs[0];
        setSystemSettings({ id: settingsDoc.id, ...settingsDoc.data() });
      } else {
        setSystemSettings({});
      }
    });

  // Registration requests collection (only supervisors for admin)
    const regRequestsUnsubscribe = onSnapshot(collection(db, "registrationRequests"), (snapshot) => {
      const requests = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })).filter(req => req.supervisorId === null);
      setRegistrationRequests(requests);
    });

    return () => {
      usersUnsubscribe();
      projectsUnsubscribe();
      tasksUnsubscribe();
      payrollUnsubscribe();
      settingsUnsubscribe();
      regRequestsUnsubscribe();
    };
  }, [user]);

  const renderContent = () => {
    switch (activeTab) {
      case "users": return <AdminUserView users={allUsers} registrationRequests={registrationRequests} />;
      case "projects": return <AdminProjectsView projects={projects} />;
      case "payroll": return <AdminPayrollView payroll={payroll} users={allUsers} tasks={tasks} />;
      case "settings": return <AdminSystemSettingsView settings={systemSettings} />;
      default: return <AdminOverviewView users={allUsers} projects={projects} tasks={tasks} payroll={payroll} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-rose-50 p-6">
      <Header />
      <div className="max-w-7xl mx-auto mt-8">
        <div className="flex border-b border-gray-200">
          <TabButton label="Overview" isActive={activeTab === 'overview'} onClick={() => setActiveTab('overview')} />
          <TabButton label="User Management" isActive={activeTab === 'users'} onClick={() => setActiveTab('users')} count={registrationRequests.filter(r => r.status === 'pending').length} />
          <TabButton label="Projects" isActive={activeTab === 'projects'} onClick={() => setActiveTab('projects')} />
          <TabButton label="Payroll" isActive={activeTab === 'payroll'} onClick={() => setActiveTab('payroll')} />
          <TabButton label="System Settings" isActive={activeTab === 'settings'} onClick={() => setActiveTab('settings')} />
        </div>
        <div className="mt-6">
          {renderContent()}
        </div>
      </div>
    </div>
  );
}

const AdminOverviewView = ({ users, projects, tasks, payroll }) => {
  const activeTasks = tasks.filter(t => t.status !== 'completed');
  const supervisors = users.filter(u => u.role === 'supervisor');

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 mb-4">System Overview</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card title="Total Users" value={users.length} />
        <Card title="Active Tasks" value={activeTasks.length} />
        <Card title="Total Supervisors" value={supervisors.length} />
        <Card title="Pending Registrations" value={users.filter(u => u.status === 'pending').length} />
      </div>
    </div>
  );
};

const AdminUserView = ({ users, registrationRequests }) => {
  const [activeSubTab, setActiveSubTab] = useState("users");

  const deleteUser = async (userId, userName) => {
    if (!window.confirm(`Are you sure you want to delete ${userName}? This action cannot be undone.`)) return;
    try {
      await deleteDoc(doc(db, "users", userId));
      alert("User deleted.");
    } catch (error) {
      console.error("Error deleting user:", error);
      alert("Failed to delete user.");
    }
  };

const handleRegistrationRequest = async (requestId, newStatus) => {
  const requestRef = doc(db, "registrationRequests", requestId);

  // Fetch regData for both approved and rejected
  const regReqDoc = await getDoc(requestRef);
  if (!regReqDoc.exists()) {
    alert("Registration request not found.");
    return;
  }
  const regData = regReqDoc.data();

  if (newStatus === 'approved') {
    try {
      // Check if a user with the same email already exists
      const usersQuery = query(collection(db, "users"), where("email", "==", regData.workerEmail));
      const usersSnapshot = await getDocs(usersQuery);
      if (!usersSnapshot.empty) {
        alert("A user with this email already exists.");
        return;
      }

      // Create user in Firebase Auth
      const userCredential = await createUserWithEmailAndPassword(auth, regData.workerEmail, regData.password);
      const firebaseUser = userCredential.user;

      // Create user document in Firestore
      await setDoc(doc(db, "users", firebaseUser.uid), {
        name: regData.workerName,
        email: regData.workerEmail,
        role: regData.supervisorId ? "worker" : "supervisor",
        supervisorId: regData.supervisorId || null,
        status: "active",
        monthlySalary: regData.supervisorId ? 10000 : 15000,
      });

      // Update the registration request status
      await updateDoc(requestRef, { status: 'approved' });
      alert(`${regData.supervisorId ? "Worker" : "Supervisor"} registration approved.`);
    } catch (error) {
      console.error("Error approving registration:", error);
      alert("Failed to approve registration: " + error.message);
    }
  } else {
    try {
      await updateDoc(requestRef, { status: 'rejected' });
      alert(`${regData.supervisorId ? "Worker" : "Supervisor"} registration rejected.`);
    } catch (error) {
      console.error("Error rejecting registration:", error);
      alert("Failed to reject registration.");
    }
  }
};

  const renderSubContent = () => {
    switch (activeSubTab) {
      case "requests":
        return (
          <div>
            <h3 className="text-xl font-bold text-gray-800 mb-4">Registration Requests</h3>
            <div className="space-y-4">
              {registrationRequests.filter(r => r.status === 'pending').length === 0 && <p className="text-gray-500">No pending requests.</p>}
              {registrationRequests.filter(r => r.status === 'pending').map(req => (
                <div key={req.id} className="p-4 border rounded-lg flex justify-between items-center">
                  <div>
                    <h4 className="font-bold">{req.workerName}</h4>
                    <p className="text-sm text-gray-600">{req.workerEmail}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      Requested on: {req.createdAt?.toDate().toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleRegistrationRequest(req.id, 'approved')}
                      className="px-3 py-1 text-sm bg-green-500 text-white rounded-md"
                    >
                      Approve
                    </button>
                    <button
                      onClick={() => handleRegistrationRequest(req.id, 'rejected')}
                      className="px-3 py-1 text-sm bg-red-500 text-white rounded-md"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      default:
        return (
          <div>
            <h3 className="text-xl font-bold text-gray-800 mb-4">All Users</h3>
            <div className="mb-6"><button className="px-4 py-2 bg-indigo-600 text-white rounded-lg">Create New User</button></div>
            <table className="w-full text-sm text-left">
              <thead className="bg-gray-50"><tr><th className="p-2">Name</th><th className="p-2">Email</th><th className="p-2">Role</th><th className="p-2">Status</th><th className="p-2">Actions</th></tr></thead>
              <tbody>{users.map(u => <tr key={u.id} className="border-b"><td className="p-2 font-medium">{u.name}</td><td className="p-2">{u.email}</td><td className="p-2 capitalize">{u.role}</td><td className="p-2"><span className={`px-2 py-1 text-xs rounded-full ${u.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>{u.status || 'active'}</span></td><td className="p-2"><button className="text-indigo-600 hover:underline mr-4">Edit</button><button onClick={() => deleteUser(u.id, u.name)} className="text-red-600 hover:underline">Delete</button></td></tr>)}</tbody>
            </table>
          </div>
        );
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">User Management</h2>
      <div className="flex border-b border-gray-200 mb-6">
        <button onClick={() => setActiveSubTab('users')} className={`py-2 px-4 text-sm font-medium ${activeSubTab === 'users' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}>All Users</button>
        <button onClick={() => setActiveSubTab('requests')} className={`py-2 px-4 text-sm font-medium ${activeSubTab === 'requests' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}>Registration Requests ({registrationRequests.filter(r => r.status === 'pending').length})</button>
      </div>
      {renderSubContent()}
    </div>
  );
};

const AdminProjectsView = ({ projects }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    startDate: '',
    endDate: '',
    budget: '',
    status: 'active'
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, "projects"), {
        ...formData,
        budget: parseFloat(formData.budget),
        createdAt: serverTimestamp(),
      });
      alert("Project created successfully!");
      setIsModalOpen(false);
      setFormData({ name: '', description: '', startDate: '', endDate: '', budget: '', status: 'active' });
    } catch (error) {
      console.error("Error creating project:", error);
      alert("Failed to create project.");
    }
  };

  const updateProjectStatus = async (projectId, newStatus) => {
    try {
      await updateDoc(doc(db, "projects", projectId), { status: newStatus });
      alert("Project status updated!");
    } catch (error) {
      console.error("Error updating project:", error);
      alert("Failed to update project.");
    }
  };

  const deleteProject = async (projectId) => {
    if (!window.confirm("Are you sure you want to delete this project?")) return;
    try {
      await deleteDoc(doc(db, "projects", projectId));
      alert("Project deleted!");
    } catch (error) {
      console.error("Error deleting project:", error);
      alert("Failed to delete project.");
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Project Management</h2>
      <div className="mb-6"><button onClick={() => setIsModalOpen(true)} className="px-4 py-2 bg-indigo-600 text-white rounded-lg">Create New Project</button></div>
      <div className="space-y-4">
        {projects.map(project => (
          <div key={project.id} className="p-4 border rounded-lg">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h3 className="font-bold text-lg">{project.name}</h3>
                <p className="text-sm text-gray-600">{project.description}</p>
                <div className="text-xs text-gray-500 mt-2 space-x-4">
                  <span>Start: {project.startDate}</span>
                  <span>End: {project.endDate}</span>
                  <span>Budget: ₹{project.budget?.toLocaleString()}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className={`px-3 py-1 text-xs font-semibold rounded-full ${project.status === 'active' ? 'bg-green-100 text-green-800' : project.status === 'completed' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'}`}>{project.status}</span>
                <select
                  value={project.status}
                  onChange={(e) => updateProjectStatus(project.id, e.target.value)}
                  className="text-xs border rounded px-2 py-1"
                >
                  <option value="active">Active</option>
                  <option value="completed">Completed</option>
                  <option value="on-hold">On Hold</option>
                </select>
                <button onClick={() => deleteProject(project.id)} className="text-red-600 hover:underline text-sm">Delete</button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-lg">
            <h3 className="text-xl font-bold mb-4">Create New Project</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <input value={formData.name} onChange={handleInputChange} name="name" placeholder="Project Name" className="w-full p-2 border rounded" required />
              <textarea value={formData.description} onChange={handleInputChange} name="description" placeholder="Description" className="w-full p-2 border rounded" rows="3"></textarea>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="block text-sm">Start Date</label><input type="date" value={formData.startDate} onChange={handleInputChange} name="startDate" className="w-full p-2 border rounded" required /></div>
                <div><label className="block text-sm">End Date</label><input type="date" value={formData.endDate} onChange={handleInputChange} name="endDate" className="w-full p-2 border rounded" required /></div>
              </div>
              <input type="number" value={formData.budget} onChange={handleInputChange} name="budget" placeholder="Budget (₹)" className="w-full p-2 border rounded" required />
              <select value={formData.status} onChange={handleInputChange} name="status" className="w-full p-2 border rounded">
                <option value="active">Active</option>
                <option value="on-hold">On Hold</option>
              </select>
              <div className="flex justify-end gap-4 mt-6">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded">Create Project</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

const AdminPayrollView = ({ payroll, users, tasks }) => {
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7));
  const [selectedSupervisor, setSelectedSupervisor] = useState("");

  const supervisors = users.filter(u => u.role === 'supervisor');

  const generatePayroll = async () => {
    const [year, month] = selectedMonth.split('-');
    const payrollMonth = `${year}-${month}`;

    try {
      // Get attendance data for the selected month
      const attendanceQuery = query(collection(db, "attendance"));
      const attendanceSnapshot = await getDocs(attendanceQuery);
      const attendanceData = attendanceSnapshot.docs.map(doc => doc.data());

      // Calculate payroll for each worker
      const payrollData = {};
      attendanceData.forEach(att => {
        if (att.date.startsWith(payrollMonth)) {
          if (!payrollData[att.workerId]) {
            payrollData[att.workerId] = { daysWorked: 0, totalHours: 0 };
          }
          payrollData[att.workerId].daysWorked += 1;
          if (att.checkIn && att.checkOut) {
            const hours = (att.checkOut.toDate() - att.checkIn.toDate()) / (1000 * 60 * 60);
            payrollData[att.workerId].totalHours += hours;
          }
        }
      });

      // Create payroll records for workers
      for (const workerId in payrollData) {
        const worker = users.find(u => u.id === workerId);
        if (worker) {
          const monthlySalary = worker.monthlySalary || 10000;
          const daysInMonth = new Date(year, month, 0).getDate();
          const dailyRate = monthlySalary / daysInMonth;
          const earnedSalary = dailyRate * payrollData[workerId].daysWorked;

          await addDoc(collection(db, "payroll"), {
            workerId,
            workerName: worker.name,
            month: payrollMonth,
            daysWorked: payrollData[workerId].daysWorked,
            totalHours: payrollData[workerId].totalHours,
            monthlySalary,
            earnedSalary,
            createdAt: serverTimestamp(),
          });
        }
      }

      // Generate supervisor payroll
      const supervisorsToPay = selectedSupervisor ? [selectedSupervisor] : supervisors.map(s => s.id);

      for (const supervisorId of supervisorsToPay) {
        const supervisor = users.find(u => u.id === supervisorId);
        if (supervisor) {
          // Calculate supervisor salary based on completed tasks by their workers
          const supervisorTasks = tasks.filter(t => t.supervisorId === supervisorId && t.status === 'completed');
          const completedTasks = supervisorTasks.length;
          const supervisorSalary = supervisor.monthlySalary || 15000;

          // Calculate earned salary based on tasks completed
          const taskBonus = completedTasks * 500; // ₹500 per completed task
          const earnedSalary = supervisorSalary + taskBonus;

          await addDoc(collection(db, "payroll"), {
            workerId: supervisorId,
            workerName: supervisor.name,
            month: payrollMonth,
            daysWorked: 30, // Assume full month for supervisors
            totalHours: 240, // Assume 8 hours/day for 30 days
            monthlySalary: supervisorSalary,
            earnedSalary,
            taskBonus,
            completedTasks,
            createdAt: serverTimestamp(),
          });
        }
      }

      alert("Payroll generated successfully!");
    } catch (error) {
      console.error("Error generating payroll:", error);
      alert("Failed to generate payroll.");
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Payroll Management</h2>
      <div className="mb-6 flex gap-4 items-center">
        <div>
          <label className="block text-sm font-medium mb-1">Month</label>
          <input
            type="month"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="p-2 border rounded"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Supervisor (Optional)</label>
          <select
            value={selectedSupervisor}
            onChange={(e) => setSelectedSupervisor(e.target.value)}
            className="p-2 border rounded"
          >
            <option value="">All Supervisors</option>
            {supervisors.map(sup => (
              <option key={sup.id} value={sup.id}>{sup.name}</option>
            ))}
          </select>
        </div>
        <div className="flex items-end">
          <button onClick={generatePayroll} className="px-4 py-2 bg-indigo-600 text-white rounded-lg">Generate Payroll</button>
        </div>
      </div>
      <table className="w-full text-sm text-left">
        <thead className="bg-gray-50"><tr><th className="p-2">Name</th><th className="p-2">Role</th><th className="p-2">Month</th><th className="p-2">Days Worked</th><th className="p-2">Total Hours</th><th className="p-2">Monthly Salary</th><th className="p-2">Earned Salary</th></tr></thead>
        <tbody>{payroll.filter(p => p.month === selectedMonth).map(p => {
          const user = users.find(u => u.id === p.workerId);
          return (
            <tr key={p.id} className="border-b">
              <td className="p-2 font-medium">{p.workerName}</td>
              <td className="p-2 capitalize">{user?.role || 'N/A'}</td>
              <td className="p-2">{p.month}</td>
              <td className="p-2">{p.daysWorked}</td>
              <td className="p-2">{p.totalHours?.toFixed(2)}</td>
              <td className="p-2">₹{p.monthlySalary?.toLocaleString()}</td>
              <td className="p-2">₹{p.earnedSalary?.toLocaleString()}</td>
            </tr>
          );
        })}</tbody>
      </table>
    </div>
  );
};

const AdminSystemSettingsView = ({ settings }) => {
  const [formData, setFormData] = useState({
    companyName: settings.companyName || '',
    companyAddress: settings.companyAddress || '',
    companyPhone: settings.companyPhone || '',
    companyEmail: settings.companyEmail || '',
    logoUrl: settings.logoUrl || '',
  });
  const [uploading, setUploading] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleLogoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    try {
      const storageRef = ref(storage, `logos/${file.name}`);
      const uploadTask = uploadBytesResumable(storageRef, file);

      uploadTask.on('state_changed',
        (snapshot) => {},
        (error) => {
          console.error("Upload error:", error);
          alert("Failed to upload logo.");
          setUploading(false);
        },
        async () => {
          const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
          setFormData(prev => ({ ...prev, logoUrl: downloadURL }));
          setUploading(false);
          alert("Logo uploaded successfully!");
        }
      );
    } catch (error) {
      console.error("Error uploading logo:", error);
      alert("Failed to upload logo.");
      setUploading(false);
    }
  };

  const handleSave = async () => {
    try {
      const settingsRef = doc(db, "systemSettings", settings.id || "main");
      await setDoc(settingsRef, formData, { merge: true });
      alert("Settings saved successfully!");
    } catch (error) {
      console.error("Error saving settings:", error);
      alert("Failed to save settings.");
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">System Settings</h2>
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-semibold mb-4">Company Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Company Name</label>
              <input
                type="text"
                name="companyName"
                value={formData.companyName}
                onChange={handleInputChange}
                className="w-full p-2 border rounded"
                placeholder="Enter company name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Company Email</label>
              <input
                type="email"
                name="companyEmail"
                value={formData.companyEmail}
                onChange={handleInputChange}
                className="w-full p-2 border rounded"
                placeholder="Enter company email"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Company Phone</label>
              <input
                type="tel"
                name="companyPhone"
                value={formData.companyPhone}
                onChange={handleInputChange}
                className="w-full p-2 border rounded"
                placeholder="Enter company phone"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium mb-2">Company Address</label>
              <textarea
                name="companyAddress"
                value={formData.companyAddress}
                onChange={handleInputChange}
                className="w-full p-2 border rounded"
                rows="3"
                placeholder="Enter company address"
              />
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-4">Company Logo</h3>
          <div className="flex items-center gap-4">
            {formData.logoUrl && (
              <img src={formData.logoUrl} alt="Company Logo" className="w-16 h-16 object-contain border rounded" />
            )}
            <div>
              <input
                type="file"
                accept="image/*"
                onChange={handleLogoUpload}
                className="hidden"
                id="logo-upload"
                disabled={uploading}
              />
              <label
                htmlFor="logo-upload"
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg cursor-pointer hover:bg-indigo-700 disabled:opacity-50"
              >
                {uploading ? "Uploading..." : "Upload Logo"}
              </label>
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <button onClick={handleSave} className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
            Save Settings
          </button>
        </div>
      </div>
    </div>
  );
};

function Card({ title, value }) {
  return (
    <div className="bg-white/90 backdrop-blur-md p-6 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
      <div className="text-sm font-semibold text-gray-600 mb-2">{title}</div>
      <div className="text-2xl font-bold text-gray-800">{value}</div>
    </div>
  );
}

function Header() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const onLogout = async () => {
    await signOut(auth);
    navigate("/", { replace: true });
  };
  return (
    <div className="flex items-center justify-between bg-white/80 backdrop-blur-md rounded-2xl p-4 shadow-lg border border-gray-100">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center text-white font-bold shadow-lg">
          <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
          </svg>
        </div>
        <div>
          <div className="font-bold text-lg text-gray-800">Labour Management System</div>
          <div className="text-xs text-gray-500 font-medium">{user?.role?.toUpperCase()}</div>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="text-sm text-gray-700 font-medium">{user?.name}</div>
        <button
          onClick={onLogout}
          className="px-4 py-2 bg-red-50 border border-red-200 rounded-xl text-sm font-medium hover:bg-red-100 transition-all duration-200 flex items-center gap-2"
        >
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M3 3a1 1 0 00-1 1v12a1 1 0 102 0V4a1 1 0 00-1-1zm10.293 9.293a1 1 0 001.414 1.414l3-3a1 1 0 000-1.414l-3-3a1 1 0 10-1.414 1.414L14.586 9H7a1 1 0 100 2h7.586l-1.293 1.293z" clipRule="evenodd" />
          </svg>
          Logout
        </button>
      </div>
    </div>
  );
}

// ---------- Auth Page (Login + Register) ----------
function AuthPage() {
  const [mode, setMode] = useState("login"); // 'login' or 'register'
  const [role, setRole] = useState("worker");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [monthlySalary, setMonthlySalary] = useState("10000");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [supervisors, setSupervisors] = useState([]);
  const [selectedSupervisor, setSelectedSupervisor] = useState('');
  const navigate = useNavigate();

  // Calculate password strength (no changes needed here)
  useEffect(() => {
    if (password.length === 0) {
      setPasswordStrength(0);
      return;
    }
    
    let strength = 0;
    if (password.length >= 8) strength += 1;
    if (/[A-Z]/.test(password)) strength += 1;
    if (/[a-z]/.test(password)) strength += 1;
    if (/[0-9]/.test(password)) strength += 1;
    if (/[^A-Za-z0-9]/.test(password)) strength += 1;
    
    setPasswordStrength(strength);
  }, [password]);

  // Auto-switch to login mode when admin is selected
  useEffect(() => {
    if (role === "admin") {
      setMode("login");
    }
  }, [role]);

  // Fetch supervisors for worker registration
  useEffect(() => {
    if (mode === "register" && role === "worker") {
      const fetchSupervisors = async () => {
        const supervisorsQuery = query(collection(db, "users"), where("role", "==", "supervisor"));
        const snapshot = await getDocs(supervisorsQuery);
        setSupervisors(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      };
      fetchSupervisors();
    }
  }, [mode, role]);

  const resetForm = () => {
    setName("");
    setEmail("");
    setPassword("");
    setConfirm("");
    setError("");
    setPasswordStrength(0);
  };

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const getPasswordStrengthText = () => {
    if (passwordStrength === 0) return "";
    if (passwordStrength <= 2) return "Weak";
    if (passwordStrength <= 3) return "Fair";
    if (passwordStrength <= 4) return "Good";
    return "Strong";
  };

  const getPasswordStrengthColor = () => {
    if (passwordStrength <= 2) return "bg-red-500";
    if (passwordStrength <= 3) return "bg-yellow-500";
    if (passwordStrength <= 4) return "bg-blue-500";
    return "bg-green-500";
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    // Validation
    if (!name.trim()) {
      setError("Full name is required");
      setIsLoading(false);
      return;
    }
    if (!email.trim()) {
      setError("Email address is required");
      setIsLoading(false);
      return;
    }
    if (!validateEmail(email)) {
      setError("Please enter a valid email address");
      setIsLoading(false);
      return;
    }
    if (password.length < 8) {
      setError("Password must be at least 8 characters long");
      setIsLoading(false);
      return;
    }
    if (passwordStrength < 3) {
      setError("Password is too weak. Please include uppercase, lowercase, numbers, and special characters");
      setIsLoading(false);
      return;
    }
    if (password !== confirm) {
      setError("Passwords do not match");
      setIsLoading(false);
      return;
    }
    if (role === "worker" && !selectedSupervisor) {
      setError("Please select a supervisor");
      setIsLoading(false);
      return;
    }

    try {
      if (role === "worker") {
        // Create registration request for worker
        await addDoc(collection(db, "registrationRequests"), {
          workerName: name,
          workerEmail: email,
          password: password, // Store temporarily, will be used to create user on approval
          supervisorId: selectedSupervisor,
          status: 'pending',
          createdAt: serverTimestamp(),
        });
        alert("Registration request submitted! Your supervisor will review it.");
      } else if (role === "admin") {
        // Create user directly for admin
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const firebaseUser = userCredential.user;

        await setDoc(doc(db, "users", firebaseUser.uid), {
          name: name,
          email: email,
          role: role.toLowerCase(),
          monthlySalary: parseFloat(monthlySalary) || 10000,
        });

        alert("Registration successful! You can now log in.");
      } else if (role === "supervisor") {
        // Create registration request for supervisor
        await addDoc(collection(db, "registrationRequests"), {
          workerName: name,
          workerEmail: email,
          password: password, // Store temporarily, will be used to create user on approval
          supervisorId: null, // Supervisors don't have supervisors
          status: 'pending',
          createdAt: serverTimestamp(),
        });
        alert("Supervisor registration request submitted! An admin will review it.");
      }
      setMode("login");
      resetForm();
    } catch (error) {
      if (error.code === 'auth/email-already-in-use') {
        setError('This email address is already registered. Please try logging in or use a different email.');
      } else {
        setError(error.message.replace('Firebase: ', ''));
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    // Validation
    if (!email.trim()) {
      setError("Email address is required");
      setIsLoading(false);
      return;
    }
    if (!validateEmail(email)) {
      setError("Please enter a valid email address");
      setIsLoading(false);
      return;
    }
    if (!password) {
      setError("Password is required");
      setIsLoading(false);
      return;
    }

    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const firebaseUser = userCredential.user;

      // Get user role from Firestore.
      const userDocRef = doc(db, "users", firebaseUser.uid);
      const userDoc = await getDoc(userDocRef);

      if (userDoc.exists()) {
        // If the document exists, check if the role matches.
        if (userDoc.data().role !== role) {
          setError("Invalid credentials or role mismatch. Please check your details and selected role.");
          await signOut(auth);
          setIsLoading(false);
          return;
        }
      } else {
        // This is a self-healing mechanism. If the user exists in Auth but not Firestore,
        // create their Firestore document. This is useful for manually created admins.
        await setDoc(userDocRef, {
          email: firebaseUser.email,
          name: role === 'admin' ? 'Admin' : "User (Profile Incomplete)", // A default name
          role: role.toLowerCase(), // Use the role they are trying to log in with
        });
      }

      // If we've reached here, the login is valid.
      if (userDoc.exists() && userDoc.data().role !== role) {
        setError("Invalid credentials or role mismatch. Please check your details and selected role.");
        await signOut(auth);
        setIsLoading(false);
        return;
      }

      // Navigate on successful login

    } catch (error) {
      if (error.code === 'auth/invalid-credential' || error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password') {
        setError('Invalid credentials. Please check your email and password.');
      } else {
        setError(error.message.replace('Firebase: ', ''));
      }
    } finally {
      setIsLoading(false);
    }

    // Navigation is now handled by the AuthProvider's onAuthStateChanged listener,
    // which will redirect upon detecting the new user state.
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-800 p-6 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%239C92AC%22%20fill-opacity%3D%220.1%22%3E%3Ccircle%20cx%3D%2230%22%20cy%3D%2230%22%20r%3D%222%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-20"></div>
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-transparent via-white/5 to-transparent"></div>
      
      <div className="w-full max-w-5xl bg-white/10 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/20 overflow-hidden relative">
        {/* Glassmorphism effect */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-white/5"></div>
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2">
          {/* Left art / info */}
          <div className="px-8 py-12 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 text-white relative overflow-hidden">
            {/* Decorative elements */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-12 -translate-x-12"></div>
            
            <div className="relative z-10">
              <div className="flex items-center gap-4 mb-8">
                <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center text-2xl font-bold shadow-lg">
                  <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
                  </svg>
                </div>
                <div>
                  <div className="text-xl font-bold">LabourMS</div>
                  <div className="text-sm opacity-80 font-medium">Smart Workforce Management</div>
                </div>
              </div>

              <h3 className="text-3xl font-bold mb-4 leading-tight">Streamline Your Workforce</h3>
              <p className="text-sm opacity-90 leading-relaxed mb-8">Join thousands of organizations managing their workforce efficiently with our comprehensive labor management platform.</p>

              <div className="mb-8">
                <div className="text-sm font-semibold mb-4 opacity-90 flex items-center gap-2">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                  </svg>
                  Select your role:
                </div>
                <div className="flex gap-3">
                  <RolePill active={role === "admin"} onClick={() => setRole("admin")} label="Admin" />
                  <RolePill active={role === "supervisor"} onClick={() => setRole("supervisor")} label="Supervisor" />
                  <RolePill active={role === "worker"} onClick={() => setRole("worker")} label="Worker" />
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-4 text-sm opacity-90 group">
                  <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center group-hover:bg-white/30 transition-colors">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span>Secure authentication & role-based access</span>
                </div>
                <div className="flex items-center gap-4 text-sm opacity-90 group">
                  <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center group-hover:bg-white/30 transition-colors">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span>Real-time attendance tracking</span>
                </div>
                <div className="flex items-center gap-4 text-sm opacity-90 group">
                  <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center group-hover:bg-white/30 transition-colors">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z" />
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span>Automated payroll management</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right: form area */}
          <div className="p-8 bg-white/5 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h3 className="text-2xl font-bold text-gray-800">
                  {role === "admin" ? "Admin Login" : mode === "login" ? "Welcome Back" : "Create Account"}
                </h3>
                <div className="text-sm text-gray-600 mt-1">
                  {role === "admin" ? "System administrator access" : "Sign in or register to continue"}
                </div>
              </div>
              {role !== "admin" && (
                <div className="text-sm">
                  <button
                    onClick={() => { setMode(mode === "login" ? "register" : "login"); setError(""); }}
                    className="px-4 py-2 rounded-xl bg-white/20 hover:bg-white/30 text-gray-700 font-medium transition-all duration-200 backdrop-blur-sm"
                  >
                    {mode === "login" ? "Register" : "Login"}
                  </button>
                </div>
              )}
            </div>

            <form onSubmit={mode === "login" ? handleLogin : handleRegister} className="space-y-6">
              {mode === "register" && role !== "admin" && (
                <div className="group">
                  <label className="block text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                    </svg>
                    Full name
                  </label>
                  <input 
                    value={name} 
                    onChange={(e) => setName(e.target.value)} 
                    className="w-full px-4 py-4 rounded-2xl border border-gray-200 bg-white/50 backdrop-blur-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300 hover:bg-white/70" 
                    placeholder="Enter your full name" 
                    disabled={isLoading}
                  />
                </div>
              )}

              <div className="group">
                <label className="block text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                    <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
                  </svg>
                  Email address
                </label>
                <input 
                  value={email} 
                  onChange={(e) => setEmail(e.target.value)} 
                  className="w-full px-4 py-4 rounded-2xl border border-gray-200 bg-white/50 backdrop-blur-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300 hover:bg-white/70" 
                  placeholder="Enter your email" 
                  disabled={isLoading}
                />
              </div>

              <div className="group">
                <label className="block text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                  </svg>
                  Password
                </label>
                <input 
                  type="password" 
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)} 
                  className="w-full px-4 py-4 rounded-2xl border border-gray-200 bg-white/50 backdrop-blur-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300 hover:bg-white/70" 
                  placeholder={mode === "login" ? "Enter your password" : "Create a strong password"} 
                  disabled={isLoading}
                />
                {mode === "register" && password && (
                  <div className="mt-3 p-3 bg-white/30 rounded-xl backdrop-blur-sm">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full transition-all duration-500 ${getPasswordStrengthColor()}`}
                          style={{ width: `${(passwordStrength / 5) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-xs font-bold text-gray-700">{getPasswordStrengthText()}</span>
                    </div>
                    <div className="text-xs text-gray-600">
                      Password must be at least 8 characters with uppercase, lowercase, numbers, and special characters
                    </div>
                  </div>
                )}
              </div>

              {mode === "register" && role !== "admin" && (
                <div className="group">
                  <label className="block text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                    </svg>
                    Confirm password
                  </label>
                  <input 
                    type="password" 
                    value={confirm} 
                    onChange={(e) => setConfirm(e.target.value)} 
                    className="w-full px-4 py-4 rounded-2xl border border-gray-200 bg-white/50 backdrop-blur-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300 hover:bg-white/70" 
                    placeholder="Confirm your password" 
                    disabled={isLoading}
                  />
                </div>
              )}

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                  </svg>
                  Role
                </label>
                <div className="flex gap-3">
                  <RolePill active={role === "admin"} onClick={() => setRole("admin")} label="Admin" />
                  <RolePill active={role === "supervisor"} onClick={() => setRole("supervisor")} label="Supervisor" />
                  <RolePill active={role === "worker"} onClick={() => setRole("worker")} label="Worker" />
                </div>
              </div>

              {mode === "register" && role === "worker" && (
                <div className="group">
                  <label className="block text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                    </svg>
                    Select Supervisor
                  </label>
                  <select
                    value={selectedSupervisor}
                    onChange={(e) => setSelectedSupervisor(e.target.value)}
                    className="w-full px-4 py-4 rounded-2xl border border-gray-200 bg-white/50 backdrop-blur-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-300 hover:bg-white/70"
                    disabled={isLoading}
                    required
                  >
                    <option value="">Choose a supervisor</option>
                    {supervisors.map(sup => (
                      <option key={sup.id} value={sup.id}>
                        {sup.name || sup.email}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {error && (
                <div className="p-4 bg-red-50/80 backdrop-blur-sm border border-red-200 rounded-2xl text-sm text-red-700 flex items-center gap-3 shadow-sm">
                  <svg className="w-5 h-5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                  <span className="font-medium">{error}</span>
                </div>
              )}

              <button 
                type="submit" 
                disabled={isLoading}
                className="w-full px-6 py-4 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold hover:from-indigo-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center gap-3 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
              >
                {isLoading ? (
                  <>
                    <svg className="animate-spin h-5 w-5" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span>{mode === "login" ? "Signing in..." : "Creating account..."}</span>
                  </>
                ) : (
                  <>
                    <span>{mode === "login" ? "Sign In" : "Create Account"}</span>
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                  </>
                )}
              </button>

              <div className="text-center text-xs text-gray-500 leading-relaxed">
                By continuing, you agree to our{" "}
                <a href="#" className="text-indigo-600 hover:text-indigo-700 font-medium underline decoration-2 underline-offset-2">Terms of Service</a>
                {" "}and{" "}
                <a href="#" className="text-indigo-600 hover:text-indigo-700 font-medium underline decoration-2 underline-offset-2">Privacy Policy</a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

function RolePill({ active, onClick, label }) {
  return (
    <button 
      onClick={onClick} 
      className={`px-5 py-3 rounded-xl text-sm font-semibold transition-all duration-300 transform hover:scale-105 ${
        active 
          ? "bg-white text-indigo-700 shadow-lg border-2 border-indigo-200 backdrop-blur-sm" 
          : "bg-white/20 text-white/90 hover:bg-white/30 backdrop-blur-sm"
      }`}
    >
      {label}
    </button>
  );
}

// ---------- Root App with routing ----------
export default function App() {
  return (
    <AuthProvider>
      <Router>
        <AppContent />
      </Router>
    </AuthProvider>
  );
}

function AppContent() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && user) {
      navigate(`/dashboard/${user.role}`, { replace: true });
    }
  }, [user, loading, navigate]);

  return (
    <Routes>
      <Route path="/" element={<AuthPage />} />

      <Route
        path="/dashboard/worker"
        element={<RequireAuth allowedRoles={["worker"]}><WorkerDashboard /></RequireAuth>}
      />
      <Route
        path="/dashboard/supervisor"
        element={<RequireAuth allowedRoles={["supervisor"]}><SupervisorDashboard /></RequireAuth>}
      />
      <Route
        path="/dashboard/admin"
        element={<RequireAuth allowedRoles={["admin"]}><AdminDashboard /></RequireAuth>}
      />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

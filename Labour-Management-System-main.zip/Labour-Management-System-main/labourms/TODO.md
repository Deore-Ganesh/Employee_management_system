# TODO: Expand Admin Functionalities with Real-Time Features

## Tasks to Complete:
- [x] Update firestore.rules for new collections (projects, payroll, systemSettings)
- [x] Modify AuthPage to create registration requests for supervisors instead of direct creation
- [x] Expand AdminDashboard with new tabs and real-time listeners
- [x] Implement Projects tab with CRUD (create, read, update, delete projects)
- [x] Implement Payroll tab with CRUD (manage salaries, generate reports)
- [x] Implement System Settings tab with company details and logo upload
- [x] Enhance User Management tab with supervisor approval/rejection
- [x] Fix registration approval hierarchy (admin only approves supervisors, supervisors approve workers)
- [x] Filter leave requests to supervisors only see those from their workers
- [x] Add notifications for leave requests to supervisors
- [x] Confirm task assignment is restricted to supervisors' workers
- [x] Test all new functionalities for real-time updates and permissions
